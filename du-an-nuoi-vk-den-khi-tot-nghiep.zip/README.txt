# Dự án nuôi vk đến khi tốt nghiệp

Website đọc truyện tĩnh, không cần framework.

## Cấu trúc
- index.html: trang chủ
- chap.html: trang đọc chap
- style.css: giao diện
- script.js: danh sách chap và nội dung

## Thêm ảnh
Bạn có thể tạo thư mục `images/`, sau đó thay các ô "ẢNH BÌA" / "ẢNH NHÂN VẬT" bằng thẻ `<img>`.

## Thêm nội dung chap
Mở `script.js`, tìm mảng `chapters` và thay `content` bằng các đoạn truyện.

## Đưa lên mạng
Có thể đăng miễn phí bằng GitHub Pages. Sau khi tải toàn bộ 4 file lên một repository, vào Settings → Pages → chọn deploy từ branch `main`.
